<?php

namespace Styde\Weapons;

use Styde\Weapon;

abstract class Bow extends Weapon
{
    
}