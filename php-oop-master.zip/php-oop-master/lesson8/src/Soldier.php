<?php

namespace Styde;

class Soldier extends Unit
{
    //
}
