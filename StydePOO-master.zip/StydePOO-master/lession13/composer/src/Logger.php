<?php
namespace Styde;

interface Logger
{
  public function info($message);
}
