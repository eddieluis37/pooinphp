<?php
namespace Styde;

interface Armor
{
  public function absorbDamage($damage);
}
